
import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aman
 */
public class AutoDialer {
    public static void main(String[] args) throws MalformedURLException, InterruptedException {
    
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "Xiaomi 12 Pro");        
        capabilities.setCapability("platformname", "Android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("platformversion", "14");        
        capabilities.setCapability("appPackage", "com.google.android.dialer");
        capabilities.setCapability("appActivity", "com.google.android.dialer.extensions.GoogleDialtactsActivity");
        
        URL url = URI.create("http://127.0.0.1:4723/").toURL();
        AndroidDriver driver = new AndroidDriver(url, capabilities);
        
        //finding elements 
        Thread.sleep(2000);
        
        WebElement dial = driver.findElement(By.id("com.google.android.dialer:id/dialpad_fab"));
        dial.click();
        
        WebElement nine = driver.findElement(By.id("com.google.android.dialer:id/nine"));       
        WebElement eight = driver.findElement(By.id("com.google.android.dialer:id/eight"));       
        WebElement six = driver.findElement(By.id("com.google.android.dialer:id/six"));
        WebElement zero = driver.findElement(By.id("com.google.android.dialer:id/zero"));
        WebElement five = driver.findElement(By.id("com.google.android.dialer:id/five"));
        WebElement one = driver.findElement(By.id("com.google.android.dialer:id/one"));
        WebElement two = driver.findElement(By.id("com.google.android.dialer:id/two"));
        WebElement seven = driver.findElement(By.id("com.google.android.dialer:id/seven"));
        
        //clicking call button
//        driver.findElement(By.id("com.google.android.dialer:id/dialpad_voice_call_button")).click();
//        WebElement delete = driver.findElement(By.xpath(""));
//        delete.click();
        
        
        //clicking numbers
        nine.click();
        eight.click();
        six.click();
        zero.click();
        zero.click();
        five.click();
        one.click();
        two.click();
        zero.click();
        seven.click();

        
        driver.findElement(By.id("com.google.android.dialer:id/dialpad_voice_call_button")).click();
        
        
        System.out.println("Succesfully Automated");
        
        Thread.sleep(3000);
        //driver.quit();
               
    }
}
