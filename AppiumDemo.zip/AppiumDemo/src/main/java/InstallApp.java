
import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aman
 */
public class InstallApp {
    
    public static void main(String[] args) throws MalformedURLException, InterruptedException {
    
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "Xiaomi 12 Pro");        
        capabilities.setCapability("platformname", "Android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("app", "/home/aman/Downloads/Sigma_v2.2.0@2b01fe43_uat_2024-06-26_17_30_08.apk");
        capabilities.setCapability("platformversion", "14");
        
        URL url = URI.create("http://127.0.0.1:4723/").toURL();
        AndroidDriver driver = new AndroidDriver(url, capabilities);
        
        Thread.sleep(3000);
        System.out.println("Application Started");
        
        Thread.sleep(3000);
        driver.quit();
        
        
        
    }
}
