
import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aman
 */
public class AutoCalculator {
    public static void main(String[] args) throws MalformedURLException, InterruptedException {
    
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "Xiaomi 12 Pro");        
        capabilities.setCapability("platformname", "Android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("platformversion", "14");        
        capabilities.setCapability("appPackage", "com.miui.calculator");
        capabilities.setCapability("appActivity", "com.miui.calculator.cal.CalculatorActivity");
        
        URL url = URI.create("http://127.0.0.1:4723/").toURL();
        AndroidDriver driver = new AndroidDriver(url, capabilities);
        
        //finding elements 
        Thread.sleep(2000);
        
        WebElement eight = driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.miui.calculator:id/digit_8\"]"));
        eight.click();
        
        driver.findElement(By.id("com.miui.calculator:id/op_add")).click();
        driver.findElement(By.id("com.miui.calculator:id/digit_2")).click();
        driver.findElement(By.id("com.miui.calculator:id/btn_equal_s")).click();
        
        String result = driver.findElement(By.id("com.miui.calculator:id/result")).getText();
        System.out.println(result);
        
        if(result.equals("= 10")) {
            System.out.println("Automation successfull");
        } else {
            System.out.println("Automation failed");
        }
       
        System.out.println("Succesfully Automated");
        
        Thread.sleep(3000);
        //driver.quit();
               
    }
}
