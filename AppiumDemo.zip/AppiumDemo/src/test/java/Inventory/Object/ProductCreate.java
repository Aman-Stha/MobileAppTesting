/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class ProductCreate {
    
    AndroidDriver driver;
    WebDriverWait wait;
    
    public ProductCreate(AndroidDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    //Basic Info
    
        By menu = By.xpath("//android.widget.Button[@content-desc='Open navigation menu']");
        By productBtn = By.xpath("//android.view.View[@content-desc=\"PRODUCT\"]");
        By itemBtn = By.xpath("//android.view.View[@content-desc=\"Items\"]");
        By bottomBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.widget.Button");
        By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.widget.Button[2]");
        By lbCode = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By pNature = By.xpath("");
        By pName = By.xpath("//android.widget.ScrollView/android.widget.EditText[3]");
        By category = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.view.View[7]/android.widget.EditText");
        By searchBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button[2]");
        By sInput = By.xpath("//android.widget.EditText");
        By selectC = By.xpath("//android.view.View[@content-desc=\"Infant Girl(0-6mth) [36622]\"]");
        By afterSelectC = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
        By nextBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Unit & Pricing
        By unitGrp = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
        By unitGrpInput = By.xpath("//android.widget.ScrollView/android.widget.EditText[1]");
        By selectUG = By.xpath("//android.view.View[@content-desc=\"litres\"]");
        //By uFactor = By.xpath("//android.widget.EditText[@text=\"1\"]");
        By apu = By.xpath("//android.view.View[@content-desc=\"Allow Decimal Quantity?\"]");
        By allowDQ = By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.CheckBox[1]");
        By showAI = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
        
//        By maxDis = By.xpath("(//android.widget.EditText[@text=\"0\"])[3]");
//        By openingRate = By.xpath("(//android.widget.EditText[@text=\"0\"])[4]");
//        By openingQuantity = By.xpath("(//android.widget.EditText[@text=\"0\"])[5]");
        By hideAI = By.xpath("//android.widget.Button[@content-desc=\"Hide Additional Info\"]");
        By showBI = By.xpath("//android.widget.Button[@content-desc=\"Show Batch Info\"]");
//        By batchNo = By.xpath("//android.widget.ScrollView/android.widget.EditText[5]");
//        By expLimit = By.xpath("//android.widget.ScrollView/android.widget.EditText[6]");
        By expType = By.xpath("//android.widget.Button[@content-desc=\"DAYS\"]");
        By selectExp = By.xpath("//android.view.View[@content-desc=\"MONTH\"]");
        By saveBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");        
        By nextBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Additional Info
        By manufacturer = By.xpath("//android.widget.ScrollView/android.widget.EditText[1]");
        By selectMan = By.xpath("//android.view.View[@content-desc=\"Automan\"]");
        By brand = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By selectB = By.xpath("//android.view.View[@content-desc=\"Tokla\"]");
        By proType = By.xpath("//android.widget.ScrollView/android.widget.EditText[3]");
        By selectPType = By.xpath("//android.view.View[@content-desc=\"3 in 1\"]");
        By attribute = By.xpath("//android.widget.ScrollView/android.widget.EditText[4]");
        By selectAttri = By.xpath("//android.view.View[@content-desc=\"samisti\"]");
        By selectAttriOpt = By.xpath("//android.view.View[@content-desc=\"whitr\"]");
        By tags = By.xpath("//android.widget.ScrollView/android.widget.EditText[5]");
        By selectTags = By.xpath("//android.view.View[@content-desc=\"new\"]");
        By reorderP = By.xpath("(//android.widget.EditText[@text=\"0\"])[1]");
        By safetyStock = By.xpath("(//android.widget.EditText[@text=\"0\"])[1]");
        By som = By.xpath("//android.widget.Button[@content-desc=\"Stock Out Method * LIFO\"]");
        By selectSOM = By.xpath("//android.view.View[@content-desc=\"FIFO\"]");
        By weightAvg = By.xpath("//android.widget.Button[@content-desc=\"Stock Valuation Method WEIGHTED_AVERAGE\"]");
        By selectWA = By.xpath("//android.view.View[@content-desc=\"LIFO\"]");
        By shortDesc = By.xpath("//android.widget.ScrollView/android.widget.EditText[6]");
        By Fulldesc = By.xpath("//android.widget.ScrollView/android.widget.EditText[7]");
        By nextBtn3 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        //WebElement view = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View"));

        //Confirmation Page
        By saveBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void Pinput(String gc, String lc, String na, String co, String hs, String cat, String vt, String ug, String cost, String sell, String pd, String sd, String md, String or, String oq, String bno, String eli, String manu, String brn, String prot, String attri, String tg, String rp, String ss, String sdec, String fdec) throws InterruptedException 
    {
        
        Thread.sleep(1000);
        driver.findElement(menu).click();
        driver.findElement(productBtn).click();
        driver.findElement(itemBtn).click();
        driver.findElement(bottomBtn).click();
        wait.until(ExpectedConditions.elementToBeClickable(addBtn)).click();
        
        WebElement gbCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]"));
        gbCode.click();
        gbCode.sendKeys(gc);
        WebElement view = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View"));
        view.click();
        
        driver.findElement(lbCode).click();
        driver.findElement(lbCode).sendKeys(lc);
        view.click();
        
        driver.findElement(pName).click();
        driver.findElement(pName).sendKeys(na);
        WebElement view1 = driver.findElement(By.xpath("//android.view.View[@content-desc=\"Product\"]"));
        view1.click();
        Thread.sleep(1000);
        
        WebElement pCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[4]"));
        pCode.click();
        pCode.sendKeys(co);
        view1.click();
        
        WebElement hsCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[5]"));
        hsCode.click();
        hsCode.sendKeys(hs);
        view1.click();
        
        wait.until(ExpectedConditions.elementToBeClickable(category)).click();
        wait.until(ExpectedConditions.elementToBeClickable(searchBtn)).click();
        driver.findElement(sInput).sendKeys(cat);
        Thread.sleep(2000);
        driver.findElement(selectC).click();
        driver.findElement(afterSelectC).click();
        wait.until(ExpectedConditions.elementToBeClickable(nextBtn1)).click();
        Thread.sleep(1000);
        
        WebElement vat = driver.findElement(By.xpath("//android.widget.EditText[@text=\"0\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(vat)).click();
        vat.clear();
        vat.sendKeys(vt);
        
        driver.findElement(unitGrp).click();
        Thread.sleep(1000);
        driver.findElement(unitGrpInput).sendKeys(ug);
        wait.until(ExpectedConditions.elementToBeClickable(selectUG)).click();
        
        WebElement cp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[4]")));
        wait.until(ExpectedConditions.elementToBeClickable(cp)).click();
        cp.clear();
        cp.sendKeys(cost);
        driver.findElement(apu).click();
        
        WebElement sp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[5]")));
        wait.until(ExpectedConditions.elementToBeClickable(sp)).click();
        sp.clear();
        sp.sendKeys(sell);
        driver.findElement(apu).click();

        wait.until(ExpectedConditions.elementToBeClickable(allowDQ)).click();
        driver.findElement(showAI).click();
        
        WebElement purchaseDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
        purchaseDis.click();
        purchaseDis.clear();
        purchaseDis.sendKeys(pd); 
        driver.findElement(apu).click();
        
        WebElement salesDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
        salesDis.click();        
        salesDis.clear();
        salesDis.sendKeys(sd);
        driver.findElement(apu).click();
        
        WebElement maxDis = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
        maxDis.click();        
        maxDis.clear();
        maxDis.sendKeys(md);
        WebElement scv = driver.findElement(By.xpath("//android.widget.ScrollView"));
        wait.until(ExpectedConditions.elementToBeClickable(scv)).click();
        
        WebElement openingRate = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
        openingRate.click();        
        openingRate.clear();
        openingRate.sendKeys(or);
        wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

        WebElement openingQuantity = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));        
        openingQuantity.click();        
        openingQuantity.clear();
        openingQuantity.sendKeys(oq);
        wait.until(ExpectedConditions.elementToBeClickable(scv)).click();

        wait.until(ExpectedConditions.elementToBeClickable(hideAI)).click();
        driver.findElement(showBI).click();
        
        WebElement batchNo = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText[6]"));
        batchNo.click();
        batchNo.sendKeys(bno);
        wait.until(ExpectedConditions.elementToBeClickable(scv)).click();
       
        WebElement expLimit = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.ScrollView/android.widget.EditText[6]")));
        expLimit.click();
        expLimit.sendKeys(eli); 
        driver.findElement(apu).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(expType)).click();
        driver.findElement(selectExp).click();
        wait.until(ExpectedConditions.elementToBeClickable(saveBtn1)).click();
        view1.click();
        wait.until(ExpectedConditions.elementToBeClickable(nextBtn2)).click();

        wait.until(ExpectedConditions.elementToBeClickable(manufacturer)).click();
        driver.findElement(manufacturer).sendKeys(manu);
        wait.until(ExpectedConditions.elementToBeClickable(selectMan)).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(brand)).click();
        driver.findElement(brand).sendKeys(brn);
        wait.until(ExpectedConditions.elementToBeClickable(selectB)).click();
        
        wait.until(ExpectedConditions.elementToBeClickable(proType)).click();
        driver.findElement(proType).sendKeys(prot);
        wait.until(ExpectedConditions.elementToBeClickable(selectPType)).click();
        view1.click();
        
        wait.until(ExpectedConditions.elementToBeClickable(attribute)).click();
        driver.findElement(attribute).sendKeys(attri);
        wait.until(ExpectedConditions.elementToBeClickable(selectAttri)).click();
        //driver.findElement(selectAttriOpt).click();
        view1.click();
        
        wait.until(ExpectedConditions.elementToBeClickable(tags)).click();
        driver.findElement(tags).sendKeys(tg);
        wait.until(ExpectedConditions.elementToBeClickable(selectTags)).click();
        view1.click();
        
        wait.until(ExpectedConditions.elementToBeClickable(reorderP)).click();
        driver.findElement(reorderP).clear();
        driver.findElement(reorderP).sendKeys(rp);
        view1.click();

        wait.until(ExpectedConditions.elementToBeClickable(safetyStock)).click();
        driver.findElement(safetyStock).clear();
        driver.findElement(safetyStock).sendKeys(ss);
        view.click();
        
        driver.findElement(som).click();
        wait.until(ExpectedConditions.elementToBeClickable(selectSOM)).click();
        
        driver.findElement(weightAvg).click();
        wait.until(ExpectedConditions.elementToBeClickable(selectWA)).click();
        
        driver.findElement(shortDesc).click();
        driver.findElement(shortDesc).sendKeys(sdec);
        driver.findElement(Fulldesc).click();
        driver.findElement(Fulldesc).sendKeys(fdec);

        wait.until(ExpectedConditions.elementToBeClickable(nextBtn3)).click();
        wait.until(ExpectedConditions.elementToBeClickable(saveBtn2)).click();
        
    }
    
    
}
