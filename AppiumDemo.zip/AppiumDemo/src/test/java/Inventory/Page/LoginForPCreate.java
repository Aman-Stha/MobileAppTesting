/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Page;

import Inventory.Object.LoginPro;
import Inventory.Object.ProductCreate;
import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class LoginForPCreate {
    
    AndroidDriver driver;
    
    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "Xiaomi 12 Pro");        
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("platformversion", "14");        
        capabilities.setCapability("appPackage", "com.syntech.smart_sme.uat");
        capabilities.setCapability("appActivity", "com.syntech.smart_sme.MainActivity");
        
        URL url = URI.create("http://127.0.0.1:4723/wd/hub").toURL();    
        driver = new AndroidDriver(url, capabilities);
    }
    
    
    @Test(priority = 1)
    public void loginOperation() throws InterruptedException {
        
        LoginPro page = new LoginPro(driver);
        page.input("asus", "sigma@123"); 
        
    }
    
    @Test(dependsOnMethods = "loginOperation")
    public void createOperation() throws InterruptedException {
        
        ProductCreate page = new ProductCreate(driver);
        page.Pinput("abcdefghijkl", "abcdefghijkl", "abcd", "abcd", "abcd", "Infant Girl", "13", "litres", "100", "200", "10", "5", "10", "100", "10", "1", "10", "Automan", "Tokla", "3 in 1", "samisti", "new", "10", "10", "This is short", "This is full");
        
    }
    
//    @AfterTest
//    public void afterTest() {
//        
//        if (driver != null) {
//            driver.quit();
//        }
//        
//    }
    
}
