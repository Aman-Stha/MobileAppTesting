/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory;

import io.appium.java_client.android.AndroidDriver;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 *
 * @author aman
 */
public class Login {
    public static void main(String[] args) throws MalformedURLException, InterruptedException {
        
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("deviceName", "Xiaomi 12 Pro");        
        capabilities.setCapability("platformname", "Android");
        capabilities.setCapability("automationName", "uiautomator2");
        capabilities.setCapability("platformversion", "14");        
        capabilities.setCapability("appPackage", "com.syntech.smart_sme.uat");
        capabilities.setCapability("appActivity", "com.syntech.smart_sme.MainActivity");
        
        URL url = URI.create("http://127.0.0.1:4723/").toURL();    
        AndroidDriver driver = new AndroidDriver(url, capabilities);
        
        
        driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_button")).click();
        Thread.sleep(1000);
        WebElement username = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[1]"));
        WebElement password = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText[2]"));
        WebElement loginBtn = driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Login\"]"));
        
        username.click();
        username.sendKeys("asus");
        password.click();
        password.sendKeys("sigma@123");
        
        driver.findElement(By.xpath("//android.view.View[@content-desc=\"Login\"]")).click();
        Thread.sleep(1000);
        loginBtn.click();
        
        Thread.sleep(2000);
        WebElement wifi = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button[2]"));
        
        if(wifi.isDisplayed()){
            System.out.println("Login Successfull");
        }else {
            System.out.println("Login Unsuccessfull");
        }
        
    }
}
