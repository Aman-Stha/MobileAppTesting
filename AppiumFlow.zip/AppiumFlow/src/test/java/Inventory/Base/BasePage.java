/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Base;

import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class BasePage {
    protected AndroidDriver driver;
    protected WebDriverWait wait;
    
    public BasePage(AndroidDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    protected void write(By locator1, String value) throws InterruptedException {
        WebElement data = driver.findElement(locator1);
        data.clear();
        data.sendKeys(value);
        Thread.sleep(500);
    }
    
    protected void Swrite(WebElement element, String value) throws InterruptedException {
        element.clear();
        element.sendKeys(value);
        Thread.sleep(500); 
    }
    
    protected void Aclick(By locator) {
        WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(locator));
        loc.click();
    }
}
