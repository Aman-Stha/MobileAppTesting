/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Page;

import Inventory.Object.CheckAnB;
import Inventory.Object.CheckStock;
import Inventory.Object.LoginPro;
import Inventory.Object.Menu;
import Inventory.Object.ProductCreate;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import io.appium.java_client.android.AndroidDriver;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class StockChecker {
    AndroidDriver driver;
    
    private String Category_Asset_Head_Balance = null;
    private String OPENING_EQUITY_Balance = null;
    private String Category_Asset_Head_Balance2 = null;
    private String OPENING_EQUITY_Balance2 = null;
    private String product = "pro3new123";
    private String initialStock = null;
    private String finalStock = null;
    
    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();
                
        capabilities.setCapability("deviceName", "sdk_gphone16k_x86_64");        
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("platformVersion", "15");        
        capabilities.setCapability("appPackage", "com.syntech.smart_sme.uat");
        capabilities.setCapability("appActivity", "com.syntech.smart_sme.MainActivity");

        URL url = URI.create("http://127.0.0.1:4723/").toURL();
        driver = new AndroidDriver(url, capabilities);
    }
    
    @Test(priority = 1)
    public void loginOperation() throws InterruptedException {
        
        LoginPro page = new LoginPro(driver);
        page.input("asus", "sigma@123"); 
        
    }
    
    @Test(dependsOnMethods = "loginOperation") 
    public void menuOperation() throws InterruptedException { 
    
        Menu pg = new Menu(driver);
        pg.proClick(false);
        
    }
    
    @Test(dependsOnMethods = "menuOperation")
    public void stockCheckOperation() throws InterruptedException {
        
        CheckStock pg = new CheckStock(driver);
        initialStock = pg.StockCheck(product);
        
    }
    
    @Test(dependsOnMethods = "stockCheckOperation")
    public void reportOpe() throws FileNotFoundException, IOException, CsvValidationException, InterruptedException {
        
        CheckAnB pg = new CheckAnB(driver);
        pg.clickAnB();
        
        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumFlow/src/test/java/CSV/accounthead.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
            String na = dt[0];
            
            try {
                String balance = pg.inputAnB(na);
                
                if ("OPENING_EQUITY".equals(na)) {
                    String[] values = balance.split("\n");
                    OPENING_EQUITY_Balance = values[3];
                    System.out.println();
                    System.out.println("*** Initial Opening Equity Balance is: " + OPENING_EQUITY_Balance + " ***");
                    System.out.println();
                }else if ("Category  Asset Head".equals(na)){
                    String[] values = balance.split("\n");
                    Category_Asset_Head_Balance = values[3];
                    System.out.println();
                    System.out.println("*** Initial Category Asset Head Balance is: " + Category_Asset_Head_Balance + " ***");
                    System.out.println();
                } else {
                    System.out.println("Invalid Account Head");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println();
                System.out.println("*** Processing To Next Data ***");
                System.out.println();
            }
        }
        
        pg.returnBack();
    }
    
    
    @Test(dependsOnMethods = "reportOpe") 
    public void menuOperation2() throws InterruptedException { 
    
        Menu pg = new Menu(driver);
        pg.proClick(true);
        
    }
    
    @Test(dependsOnMethods = "menuOperation2")
    public void createOperation() throws FileNotFoundException, InterruptedException, IOException, CsvValidationException {
        
        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumFlow/src/test/java/CSV/product.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
           
            String gc = dt[0];
            String lc = dt[1];
            String nature = dt[2];
            String na = dt[3];
            String co = dt[4];
            String hs = dt[5];
            String cat = dt[6];
            String vt = dt[7];
            String ug = dt[8];
            String cost = dt[9];
            String sell = dt[10];
            String pd = dt[11];
            String sd = dt[12];
            String md = dt[13];
            String or = dt[14];
            String oq = dt[15];
            String bno = dt[16];
            String eli = dt[17];
            String expType = dt[18];
            String manu = dt[19];
            String brn = dt[20];
            String prot = dt[21];
            String attri = dt[22];
            String tg = dt[23];
            String rp = dt[24];
            String ss = dt[25];
            String som = dt[26];
            String svm = dt[27];
            String sdec = dt[28];
            String fdec = dt[29];

            try {
                ProductCreate page = new ProductCreate(driver);
                page.Pinput(gc, lc, na, co, hs, cat, vt, ug, cost, sell, pd, sd, md, or, oq, bno, eli, manu, brn, prot, attri, tg, rp, ss, sdec, fdec);            
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println();
                System.out.println("*** Processing To Next Data ***");
                System.out.println();
            }            
        } 
    }
    
    @Test(dependsOnMethods = "createOperation") 
    public void menuOperation3() throws InterruptedException { 
    
        Menu pg = new Menu(driver);
        pg.proClick(true);
        
    }
    
    @Test(dependsOnMethods = "menuOperation3")
    public void stockCheckOperation2() throws InterruptedException {
        
        CheckStock pg = new CheckStock(driver);
        finalStock = pg.StockCheck(product);
        
    }
    
    @Test(dependsOnMethods = "stockCheckOperation2")
    public void reportOpe2() throws FileNotFoundException, IOException, CsvValidationException, InterruptedException {
        
        CheckAnB pg = new CheckAnB(driver);
        pg.clickAnB();
        
        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumFlow/src/test/java/CSV/accounthead.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
            String na = dt[0];
            
            try {
                String balance = pg.inputAnB(na);
                
                if ("OPENING_EQUITY".equals(na)) {
                    String[] values = balance.split("\n");
                    OPENING_EQUITY_Balance2 = values[3];
                }else {
                    String[] values = balance.split("\n");
                    Category_Asset_Head_Balance2 = values[3];
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println();
                System.out.println("*** Processing To Next Data ***");
                System.out.println();
            }
        }
        System.out.println();
        System.out.println("*** Final Opening Equity Balance is: " + OPENING_EQUITY_Balance2 + " ***");
        System.out.println();
        System.out.println();
        System.out.println("*** Final Category Asset Head Balance is: " + Category_Asset_Head_Balance2 + " ****");
        System.out.println();
        
        pg.returnBack();
    }
        
    @Test(dependsOnMethods = "reportOpe2")
    public void compareBalance() throws FileNotFoundException, IOException, CsvValidationException {
        
        double stock = Double.parseDouble(finalStock) - Double.parseDouble(initialStock);
        System.out.println();
        System.out.println("*** Difference in stock is: " + stock + " ***");
        System.out.println();

        double value1 = Double.parseDouble(OPENING_EQUITY_Balance2) - Double.parseDouble(OPENING_EQUITY_Balance);
        System.out.println();
        System.out.println("*** Difference in Openinig Equity is: " + value1 + " ***");
        System.out.println();

        double value2 = Double.parseDouble(Category_Asset_Head_Balance2) - Double.parseDouble(Category_Asset_Head_Balance);
        System.out.println();
        System.out.println("*** Difference in Category Asset Head is: " + value2 + " ***");
        System.out.println();

        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumFlow/src/test/java/CSV/compare.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
            int st = Integer.parseInt(dt[0]);
            int v1 = Integer.parseInt(dt[1]);
            int v2 = Integer.parseInt(dt[2]);
            
            if(stock == st && value1 == v1 && value2 == v2) {
                System.out.println();
                System.out.println("*** Congratulations Test Passed Successfully ***");
                System.out.println();
            } else {
                System.out.println();
                System.out.println("*** Oppsss Test Failed ***");
                System.out.println();
            }
        }
    }
}
