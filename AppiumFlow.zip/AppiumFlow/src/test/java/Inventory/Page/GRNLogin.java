/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Page;

import Inventory.Object.CreateCustomer;
import Inventory.Object.PurchaseReturn;
import Inventory.Object.GRN;
import Inventory.Object.LoginPro;
import Inventory.Object.Menu;
import Inventory.Object.ProductCreate;
import Inventory.Object.PurchaseOrder;
import Inventory.Object.SalesOrder;
import Inventory.Object.SalesReturn;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import io.appium.java_client.android.AndroidDriver;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author aman
 */
public class GRNLogin {
    
    AndroidDriver driver;
    String supp = "abab";
    String cust = "miya";
    String prod = "earpods123";
    
    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        
        //Gather desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();
                
        capabilities.setCapability("deviceName", "sdk_gphone16k_x86_64");        
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("platformVersion", "15");        
        capabilities.setCapability("appPackage", "com.syntech.smart_sme.uat");
        capabilities.setCapability("appActivity", "com.syntech.smart_sme.MainActivity");

        URL url = URI.create("http://127.0.0.1:4723/").toURL(); 
        driver = new AndroidDriver(url, capabilities);
    }

    @Test(priority = 1)
    public void loginOperation() throws InterruptedException {
        
        LoginPro page = new LoginPro(driver);
        page.input("asus", "sigma@123"); 
        
    }
    
    @Test(dependsOnMethods = "loginOperation") 
    public void menuOperation() throws InterruptedException { 
    
        Menu pg = new Menu(driver);
        pg.proClick(false);
        
    }
    
    /*
    @Test(dependsOnMethods = "menuOperation")
    public void proCreate() throws FileNotFoundException, IOException, CsvValidationException {
        
        CSVReader data = new CSVReader(new FileReader("/home/aman/NetBeansProjects/AppiumFlow/src/test/java/CSV/product.csv"));
        data.readNext();
        String[] dt;
        
        while((dt=data.readNext())!=null) {
           
            String gc = dt[0];
            String lc = dt[1];
            String nature = dt[2];
            String na = dt[3];
            String co = dt[4];
            String hs = dt[5];
            String cat = dt[6];
            String vt = dt[7];
            String ug = dt[8];
            String cost = dt[9];
            String sell = dt[10];
            String pd = dt[11];
            String sd = dt[12];
            String md = dt[13];
            String or = dt[14];
            String oq = dt[15];
            String bno = dt[16];
            String eli = dt[17];
            String expType = dt[18];
            String manu = dt[19];
            String brn = dt[20];
            String prot = dt[21];
            String attri = dt[22];
            String tg = dt[23];
            String rp = dt[24];
            String ss = dt[25];
            String som = dt[26];
            String svm = dt[27];
            String sdec = dt[28];
            String fdec = dt[29];

            try {
                ProductCreate page = new ProductCreate(driver);
                page.Pinput(gc, lc, na, co, hs, cat, vt, ug, cost, sell, pd, sd, md, or, oq, bno, eli, manu, brn, prot, attri, tg, rp, ss, sdec, fdec);            
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.println();
                System.out.println("*** Processing To Next Data ***");
                System.out.println();
            }            
        }
        
    }
*/
    
//    @Test(dependsOnMethods = "menuOperation")
//    public void CreatePO() throws InterruptedException {
//        PurchaseOrder page = new PurchaseOrder(driver);
//        page.POinput("abab","earpods123","10"); 
//    }
//    
    @Test(dependsOnMethods = "menuOperation")
    public void createGRN() throws InterruptedException { 
    
        GRN pg = new GRN(driver);
        pg.grnInput("abab","10","1000","teller");
        pg.purchaseBill();
        
    }
//     
//    @Test(dependsOnMethods = "menuOperation") 
//    public void purchaseRtn() throws InterruptedException { 
//    
//        PurchaseReturn pg = new PurchaseReturn(driver);
//        pg.debitInput(supp);
//        
//    }
    
//    @Test(dependsOnMethods = "menuOperation")
//    public void salesOperation() throws InterruptedException { 
//    
//        Menu pg = new Menu(driver);
//        pg.Sclick();
//        
//    }
    
//    @Test(dependsOnMethods = "menuOperation")
//    public void CreateSO() throws InterruptedException {
//        SalesOrder pg = new SalesOrder(driver);
//        pg.SOinput(cust,prod,"10");
//        pg.salesInvoice();
//    }

    @Test(dependsOnMethods = "createGRN")
    public void SalesR() throws InterruptedException {
        
        SalesReturn pg = new SalesReturn(driver);
        pg.rInput(cust);
        
    }
    
    @Test(dependsOnMethods = "SalesR")
    public void cusCreate() throws InterruptedException {
        
        CreateCustomer pg = new CreateCustomer(driver);
        pg.Cusinput("miya", "legends", "98834627489", "miya@gmail.com", "miya123", "989873232", "10", "100");
        
    }
    
}
