/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class PurchaseBill extends BasePage {
    
    public PurchaseBill(AndroidDriver driver){
        super(driver);
    }

    By purchaseBill = By.xpath("//android.view.View[@content-desc=\"Purchase Bill\"]");
    By add = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
    By selectGRN = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.CheckBox[1]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    By back = By.xpath("//android.widget.Button[@content-desc=\"Back\"]");
    
    public void PbInput() throws InterruptedException {
        
        Aclick(purchaseBill);
        Aclick(add);
        Aclick(dismiss);
        
        WebElement supplier = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText"));
        supplier.click();
        List<WebElement> suppList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectS = suppList.get(12);
        wait.until(ExpectedConditions.elementToBeClickable(SelectS)).click();
        Thread.sleep(1000);
        
        Aclick(selectGRN);
                
        //android.widget.FrameLayout[@resource-id="android:id/content"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[6]/android.widget.EditText
        WebElement grn = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[6]/android.widget.EditText"));
        grn.click();
        List<WebElement> grnList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectG = grnList.get(10);
        wait.until(ExpectedConditions.elementToBeClickable(SelectG)).click();
        Thread.sleep(1000);
        
        Aclick(save);
        System.out.println();
        System.out.println("*** Successfully added purchase bill ***");
        System.out.println();
        
        Thread.sleep(2000);
        Aclick(back);
    }
}
