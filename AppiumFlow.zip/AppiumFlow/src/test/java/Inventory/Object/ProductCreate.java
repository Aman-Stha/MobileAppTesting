/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class ProductCreate extends BasePage {
    
   
    
    public ProductCreate(AndroidDriver driver) {
        super(driver);
    }
    
    //Basic Info
            
        By bottomBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[3]/android.widget.Button");
        By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.widget.Button[2]");
        By lbCode = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By pNature = By.xpath("");
        By category = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.view.View[9]/android.widget.EditText");
        By searchBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button[2]");
        By sInput = By.xpath("//android.widget.EditText");
        By afterSelectC = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
        By nextBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Unit & Pricing
        By unitGrp = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
        By unitGrpInput = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
        By allowDQ = By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.CheckBox[1]");
        By isDefault = By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.CheckBox[2]");
        By addUnit = By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[1]");
        
        By showAI = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
        By hideAI = By.xpath("//android.widget.Button[@content-desc=\"Hide Additional Info\"]");
        By showBI = By.xpath("//android.widget.Button[@content-desc=\"Show Batch Info\"]");
        By expType = By.xpath("//android.widget.Button[@content-desc=\"DAYS\"]");
        By selectExp = By.xpath("//android.widget.Button[@content-desc=\"MONTH\"]");
        By saveBtn1 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");        
        By nextBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
        
        //Additional Info
        By manufacturer = By.xpath("//android.widget.ScrollView/android.widget.EditText[1]");
        By brand = By.xpath("//android.widget.ScrollView/android.widget.EditText[2]");
        By proType = By.xpath("//android.widget.ScrollView/android.widget.EditText[3]");
        By attribute = By.xpath("//android.widget.ScrollView/android.widget.EditText[4]");
        By som = By.xpath("//android.widget.Button[@content-desc='Stock Out Method*\nLIFO']");
        By selectSOM = By.xpath("//android.view.View[@content-desc=\"FIFO\"]");
        By weightAvg = By.xpath("//android.widget.Button[@content-desc=\"Stock Valuation Method WEIGHTED_AVERAGE\"]");
        By selectWA = By.xpath("//android.view.View[@content-desc=\"LIFO\"]");
        By nextBtn3 = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");

        //Confirmation Page
        By saveBtn2 = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void Pinput(String gc, String lc, String na, String co, String hs, String cat, String vt, String ug, String cost, String sell, String pd, String sd, String md, String or, String oq, String bno, String eli, String manu, String brn, String prot, String attri, String tg, String rp, String ss, String sdec, String fdec) throws InterruptedException 
    {
        
        Aclick(bottomBtn);
        Aclick(addBtn);
        Thread.sleep(1000);
        
        WebElement gbCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]"));
        gbCode.click();
        gbCode.sendKeys(gc);
        Thread.sleep(500);
        
        wait.until(ExpectedConditions.elementToBeClickable(lbCode)).click();
        driver.findElement(lbCode).sendKeys(lc);
        Thread.sleep(500);
        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
        WebElement pName = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[3]"));
        wait.until(ExpectedConditions.elementToBeClickable(pName)).click();
        pName.sendKeys(na);        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Thread.sleep(500);

        WebElement pCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[4]"));
        wait.until(ExpectedConditions.elementToBeClickable(pCode)).click();
        pCode.sendKeys(co);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Thread.sleep(500);
        
        WebElement hsCode = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.widget.EditText[5]"));
        hsCode.click();
        hsCode.sendKeys(hs);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Thread.sleep(500);
        
        wait.until(ExpectedConditions.elementToBeClickable(category)).click();
        wait.until(ExpectedConditions.elementToBeClickable(searchBtn)).click();
        driver.findElement(sInput).sendKeys(cat);
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));
        Thread.sleep(1000);
        
        List<WebElement> catList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectC = catList.get(8);
        wait.until(ExpectedConditions.elementToBeClickable(SelectC)).click();
        driver.findElement(afterSelectC).click();
        wait.until(ExpectedConditions.elementToBeClickable(nextBtn1)).click();
        Thread.sleep(1000);
        
        WebElement vat = driver.findElement(By.xpath("//android.widget.EditText[@text=\"0\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(vat)).click();
        vat.clear();
        vat.sendKeys(vt);
        
        driver.findElement(unitGrp).click();
        Thread.sleep(1000);
        driver.findElement(unitGrpInput).sendKeys(ug);
        List<WebElement> ugList = driver.findElements(By.xpath("//android.view.View"));
        WebElement selectUG = ugList.get(14);
        wait.until(ExpectedConditions.elementToBeClickable(selectUG)).click();

        WebElement cp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[4]")));
        wait.until(ExpectedConditions.elementToBeClickable(cp)).click();
        cp.clear();
        cp.sendKeys(cost);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement sp = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[5]")));
        wait.until(ExpectedConditions.elementToBeClickable(sp)).click();
        sp.clear();
        sp.sendKeys(sell);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        Aclick(allowDQ);
        Aclick(isDefault);
        Aclick(showAI);

        WebElement purchaseDis = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]")));
        wait.until(ExpectedConditions.elementToBeClickable(purchaseDis)).click();
        purchaseDis.clear();
        purchaseDis.sendKeys(pd); 
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement salesDis = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]")));
        wait.until(ExpectedConditions.elementToBeClickable(salesDis)).click();
        salesDis.clear();
        salesDis.sendKeys(sd);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement maxDis = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]")));
        wait.until(ExpectedConditions.elementToBeClickable(maxDis)).click();
        maxDis.clear();
        maxDis.sendKeys(md);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement openingRate = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]")));
        wait.until(ExpectedConditions.elementToBeClickable(openingRate)).click();
        openingRate.clear();
        openingRate.sendKeys(or);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement openingQuantity = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]")));        
        wait.until(ExpectedConditions.elementToBeClickable(openingQuantity)).click();
        openingQuantity.clear();
        openingQuantity.sendKeys(oq);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        Aclick(hideAI);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(showBI);

        WebElement batchNo = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[6]")));
        wait.until(ExpectedConditions.elementToBeClickable(batchNo)).click();
        batchNo.sendKeys(bno);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Thread.sleep(500);

        WebElement expLimit = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.view.View[@content-desc=\"Add Product Unit\"]/android.view.View/android.widget.EditText[7]")));
        wait.until(ExpectedConditions.elementToBeClickable(expLimit)).click();
        expLimit.sendKeys(eli);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        Aclick(expType);
        Aclick(selectExp);
        Aclick(saveBtn1);
        Aclick(nextBtn2);
        Thread.sleep(1000);

        Aclick(manufacturer);
        driver.findElement(manufacturer).sendKeys(manu);
        Thread.sleep(1000);
        
        WebElement selectMan = driver.findElement(By.xpath("//android.view.View[@content-desc='" + manu + "']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectMan)).click();

        Aclick(brand);
        driver.findElement(brand).sendKeys(brn);
        Thread.sleep(1000);
        WebElement selectB = driver.findElement(By.xpath("//android.view.View[@content-desc='" + brn + "']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectB)).click();
        
        Aclick(proType);
        driver.findElement(proType).sendKeys(prot);
        Thread.sleep(1000);
        WebElement selectPType = driver.findElement(By.xpath("//android.view.View[@content-desc='" + prot + "']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectPType)).click();

        Aclick(attribute);
        driver.findElement(attribute).sendKeys(attri);
        Thread.sleep(1000);
        WebElement selectAttri = driver.findElement(By.xpath("//android.view.View[@content-desc='" + attri + "']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectAttri)).click();

        WebElement attriOpt = driver.findElement(By.xpath("//android.view.View[@content-desc='1']"));
        wait.until(ExpectedConditions.elementToBeClickable(attriOpt)).click();
        
        WebElement tag = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText[5]"));
        wait.until(ExpectedConditions.elementToBeClickable(tag)).click();
        tag.sendKeys(tg);
        Thread.sleep(500);
        WebElement selectTags = driver.findElement(By.xpath("//android.view.View[@content-desc='" + tg + "']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectTags)).click();
        
        List<WebElement> edit = driver.findElements(By.className("android.widget.EditText"));
        WebElement reorderP = edit.get(5);
        wait.until(ExpectedConditions.elementToBeClickable(reorderP)).click();
        reorderP.clear();
        reorderP.sendKeys(rp);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement safetyStock = edit.get(6);
        wait.until(ExpectedConditions.elementToBeClickable(safetyStock)).click();
        safetyStock.clear();
        safetyStock.sendKeys(ss);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
        WebElement shortDesc = edit.get(7);
        shortDesc.click();
        shortDesc.sendKeys(sdec);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

//        WebElement fullDesc = edit.get(8);
//        wait.until(ExpectedConditions.elementToBeClickable(fullDesc)).click();
//        fullDesc.sendKeys(fdec);
//        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        wait.until(ExpectedConditions.elementToBeClickable(nextBtn3)).click();
        wait.until(ExpectedConditions.elementToBeClickable(saveBtn2)).click();
        Thread.sleep(1000);
        
        System.out.println();
        System.out.println("*** Congratulations Product Created Successfully ***");
        System.out.println();
        
        WebElement back = driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Back\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(back)).click();
        
        WebElement productBtn = driver.findElement(By.xpath("//android.view.View[@content-desc=\"PRODUCT\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(productBtn)).click();

        
    }
}
