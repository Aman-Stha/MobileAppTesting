/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class PurchaseOrder extends BasePage {
    
    public PurchaseOrder(AndroidDriver driver) {
        super(driver);
    }
    
    By porder = By.xpath("//android.view.View[@content-desc=\"Purchase order\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
    By addItem = By.xpath("//android.widget.Button[@content-desc=\"Add Item\"]");
    By product = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
//    By out = By.xpath("//android.view.View[@content-desc=\"Add Item\"]");
//    By cp = By.xpath("");
//    By showMore = By.xpath("");
//    By dis = By.xpath("");
//    By vat = By.xpath("");
    By addPro = By.xpath("//android.widget.Button[@content-desc=\"Add\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");    
    
    public void POinput(String sup, String pro, String quan) throws InterruptedException {
        
        Aclick(porder);
        Aclick(addBtn);
        Aclick(dismiss);
        
        WebElement supplier = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText"));
        Swrite(supplier, sup);
        Wclick(sup);
        
        Aclick(addItem);
        
        Write(product, pro);
        Wclick(pro);
        
        WebElement quantity = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
        Swrite(quantity, quan);
        
        Aclick(addPro);
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully added purchase order ***");
        System.out.println();
        
        Thread.sleep(2000);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
    }
}
