/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class SalesReturn extends BasePage{
    
    public SalesReturn(AndroidDriver driver) {
        
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));

    }
    
    By Sreturn = By.xpath("//android.view.View[@content-desc=\"Sales Return\"]");   
    By add = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By customer = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By invoiceNo = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    By next = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
    By finish = By.xpath("//android.widget.Button[@content-desc=\"Finish\"]");
    
    public void rInput(String cus) throws InterruptedException {
        
        Aclick(Sreturn);
        Aclick(add);
        
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(finish);
        
        Write(customer, cus);
        Wclick(cus);
        
        Aclick(invoiceNo);
        List<WebElement> invList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectINV = invList.get(8);
        wait.until(ExpectedConditions.elementToBeClickable(SelectINV)).click();
        Thread.sleep(1000);
        
        String MobElementToScroll = "Amount in words";
        WebElement SwitchElement = driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
        + ".scrollIntoView(new UiSelector().description(\"" + MobElementToScroll + "\"))"));
        SwitchElement.click();
        Thread.sleep(500);
        
        WebElement remarks = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText"));
        Swrite(remarks, "done");

        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully created sales return ***");
        System.out.println();
                
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

    }
}
