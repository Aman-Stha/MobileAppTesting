/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class DebitNote extends BasePage{
    
    public DebitNote(AndroidDriver driver) {
        super(driver);
    }
    
    By purchaseReturn = By.xpath("//android.view.View[@content-desc=\"Purchase Return\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
//    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
    By supplier = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
    By grn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]");
    By addItem = By.xpath("//android.widget.Button[@content-desc=\"Add Item\"]");
    By next = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
    By finish = By.xpath("//android.widget.Button[@content-desc=\"Finish\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");

    
    public void debitInput() throws InterruptedException {
        
        Aclick(purchaseReturn);
        Aclick(addBtn);
        
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(next);
        Aclick(finish);
        
        Aclick(supplier);
        
        List<WebElement> suppList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectS = suppList.get(2);
        wait.until(ExpectedConditions.elementToBeClickable(SelectS)).click();
        Thread.sleep(1000);
        
        Aclick(grn);
        List<WebElement> grnList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectGRN = grnList.get(8);
        wait.until(ExpectedConditions.elementToBeClickable(SelectGRN)).click();
        Thread.sleep(1000);
        
        Aclick(addItem);
        
        List<WebElement> itemList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectI = itemList.get(7);
        wait.until(ExpectedConditions.elementToBeClickable(SelectI)).click();
        Thread.sleep(1000);
        
        String MobElementToScroll = "Multiple Payments";
        WebElement SwitchElement = driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
        + ".scrollIntoView(new UiSelector().description(\"" + MobElementToScroll + "\"))"));
        SwitchElement.click();
        
        WebElement remarks = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.EditText"));
        remarks.click();
        remarks.sendKeys("done");
        
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully created purchase return ***");
        System.out.println();
        
    }   
}
