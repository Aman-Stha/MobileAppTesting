/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 *
 * @author aman
 */
public class Menu extends BasePage {
    
    public Menu(AndroidDriver driver) {
        
        super(driver);
        
    }
    
    By menu = By.xpath("//android.widget.Button[@content-desc='Open navigation menu']");
    By productBtn = By.xpath("//android.view.View[@content-desc=\"PRODUCT\"]");
    By itemBtn = By.xpath("//android.view.View[@content-desc=\"Items\"]");
//    By purchase = By.xpath("//android.view.View[@content-desc=\"PURCHASE\"]");
    By porder = By.xpath("//android.view.View[@content-desc=\"Purchase order\"]");
    By sales = By.xpath("//android.view.View[@content-desc=\"SALES\"]");
    By sorder = By.xpath("//android.view.View[@content-desc=\"Sales Order\"]");
    By reportBtn = By.xpath("//android.view.View[@content-desc=\"REPORT\"]");
    
    public void proClick(boolean skipFirstClick) throws InterruptedException {
    if (!skipFirstClick) {
        Aclick(menu);
    }
    Aclick(productBtn);
    Aclick(itemBtn);
}

    
    public void Pclick() throws InterruptedException {

//        Aclick(menu);
        WebElement purchase = driver.findElement(By.xpath("//android.view.View[@content-desc=\"PURCHASE\"]"));
        wait.until(ExpectedConditions.elementToBeClickable(purchase)).click();
        //Aclick(porder);
    }
    
    public void Sclick() {
//        driver.findElement(menu).click();
        Aclick(sales);
        Aclick(sorder);
    }
    
    public void Rclick() throws InterruptedException {
        
//        Aclick(menu);
        Aclick(reportBtn);
    
    }
}
