/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * 
 * @author aman
 */
public class SalesOrder extends BasePage{
    
    public SalesOrder(AndroidDriver driver) {
        super(driver);
    }
        
    By sorder = By.xpath("//android.view.View[@content-desc=\"Sales Order\"]");
    By addBtn = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By dismiss = By.xpath("//android.view.View[@content-desc=\"Dismiss\"]");
    By customer = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText");
    By addItem = By.xpath("//android.widget.Button[@content-desc=\"Add Item\"]");
    By product = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]");
//    By out = By.xpath("//android.view.View[@content-desc=\"Add Item\"]");
    By addPro = By.xpath("//android.widget.Button[@content-desc=\"Add\"]");
//    By so = By.xpath("//android.view.View[@content-desc=\"Sales Order\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");    
    
    //Convert to sales invoice
    By convert = By.xpath("//android.widget.Button[@content-desc=\"Convert To Sales Invoice\"]");
    By addSIitem = By.xpath("//android.widget.Button[@content-desc=\"Add Item\"]");
    By nextBtn = By.xpath("//android.widget.Button[@content-desc=\"Next\"]");
    By cross = By.xpath("//android.view.View[@content-desc=\"Select a customer\"]/android.widget.Button[1]");
    
    
    public void SOinput(String cus,String pro, String quan) throws InterruptedException {
        
        Aclick(sorder);
        Aclick(addBtn);
        try {
            Aclick(dismiss);
        } catch (Exception e) {
        }
        
        Write(customer, cus);
        Wclick(cus);
        
//        Aclick(customer);
//        Thread.sleep(1000);
//        List<WebElement> cusList = driver.findElements(By.xpath("//android.view.View"));
//        WebElement SelectC = cusList.get(12);
//        wait.until(ExpectedConditions.elementToBeClickable(SelectC)).click();
//        Thread.sleep(1000);
        
        Aclick(addItem);
        
        Write(product, pro);
        Wclick(pro);
        
//        Aclick(product);
//        Thread.sleep(1000);
//        
//        List<WebElement> proList = driver.findElements(By.xpath("//android.view.View"));
//        WebElement SelectP = proList.get(12);
//        wait.until(ExpectedConditions.elementToBeClickable(SelectP)).click();
//        Thread.sleep(1000);
        
        WebElement quantity = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
        Swrite(quantity, quan);
//        quantity.click();
//        quantity.clear();
//        quantity.sendKeys(quan);
        
        List <WebElement> spList = driver.findElements(By.xpath("//android.widget.EditText"));
        WebElement sp1 = spList.get(2);
        String text = sp1.getText();
        
        if(text.equals("0")) {
            
            Swrite(sp1, "1");
            System.out.println();
            System.out.println("*** Selling Price cannot be 0 so I changed it to 1 ***");
            System.out.println();

        }
        
        Aclick(addPro);
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully added sales order ***");
        System.out.println();
        
    }
    
    public void salesInvoice() throws InterruptedException {
        
        Aclick(convert);
        Aclick(addSIitem);
        
        List<WebElement> itemList = driver.findElements(By.xpath("//android.view.View"));
        WebElement SelectI = itemList.get(7);
        wait.until(ExpectedConditions.elementToBeClickable(SelectI)).click();
        Thread.sleep(1000);
        
        Aclick(nextBtn);
        Aclick(save);
        Aclick(cross);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
        System.out.println();
        System.out.println("*** Successfully created sales invoice ***");
        System.out.println();
        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

    }
}
