/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/**
 *
 * @author aman
 */
public class CheckAnB extends BasePage {
    
    private String finalBalance;

    
    public CheckAnB(AndroidDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    By viewAll = By.xpath("//android.view.View[@content-desc=\"View all reports\"]");
    By subledgerReport = By.xpath("//android.view.View[@content-desc=\"Sub ledger Report\"]");
//    By selectAccHead = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.widget.EditText");
    By year = By.xpath("//android.widget.Button[@content-desc=\"Select year\"]");
    By selectY = By.xpath("//android.widget.Button[@content-desc=\"2025\"]");
    By ok = By.xpath("//android.widget.Button[@content-desc=\"OK\"]");
    By reportBtn = By.xpath("//android.view.View[@content-desc=\"REPORT\"]");

    
    public void clickAnB() throws InterruptedException {
        
        Aclick(reportBtn);
        Aclick(viewAll);
        
        String MobElementToScroll = "Sub ledger Report";
        WebElement SwitchElement = driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true))"
        + ".scrollIntoView(new UiSelector().description(\"" + MobElementToScroll + "\"))"));
        SwitchElement.click();
        
        Aclick(subledgerReport);
        
        List<WebElement> dateList = driver.findElements(By.xpath("//android.widget.EditText"));
        WebElement dateOpt = dateList.get(1);
        dateOpt.click();
        
        Aclick(year);
        Aclick(selectY);
        Aclick(ok);
        Aclick(ok);
        
        WebElement dateOpt2 = dateList.get(2);
        dateOpt2.click();
        
        Aclick(year);
        Aclick(selectY);
        Aclick(ok);
        Aclick(ok);
    }
    
    public String inputAnB(String acchead) throws InterruptedException {
        
//        Aclick(selectAccHead);
        
        List<WebElement> AccHead = driver.findElements(By.className("android.widget.EditText"));
        WebElement selectAccHead = AccHead.get(0);
        selectAccHead.click();
        selectAccHead.clear();
        selectAccHead.sendKeys(acchead);
                
//        driver.findElement(selectAccHead).clear();
//        driver.findElement(selectAccHead).sendKeys(acchead);
        Thread.sleep(1000);
        
        WebElement accList = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.view.View[@content-desc='" + acchead + "']")));
        accList.click();
        Thread.sleep(1000);
        
        List<WebElement> balanceList = driver.findElements(By.xpath("//android.view.View"));
            WebElement SelectS = balanceList.get(18);
            String balance = SelectS.getAttribute("content-desc");
            finalBalance = balance;
            return finalBalance;
    }
    
    
    public void returnBack() throws InterruptedException {
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Aclick(reportBtn);
    }
}
