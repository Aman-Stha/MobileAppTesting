/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class CreateCustomer extends BasePage {
    
    public CreateCustomer(AndroidDriver driver) {
        
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));        
        
    }
    
    By customer = By.xpath("//android.view.View[@content-desc=\"Customers\"]");
    By add = By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button");
    By addInfo = By.xpath("//android.widget.Button[@content-desc=\"Show Additional Info\"]");
    By category = By.xpath("//android.widget.Button[@content-desc=\"Select Category\"]");
    By categorySelect = By.xpath("//android.widget.Button[@content-desc=\"B\"]");
    By save = By.xpath("//android.widget.Button[@content-desc=\"Save\"]");
    
    public void Cusinput(String nam, String addr, String ph, String ema,String cod, String pan, String creL, String creA) throws InterruptedException {
        
        Aclick(customer);
        Aclick(add);
        
        WebElement name = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View[1]/android.widget.EditText"));
        Swrite(name, nam);
        
        WebElement address = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[1]"));
        Swrite(address, addr);
        
        WebElement phone = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[2]"));
        Swrite(phone, ph);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        Aclick(addInfo);
        Thread.sleep(1000);
        
        WebElement email = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[3]"));
        Swrite(email, ema);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement code = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[4]"));
        Swrite(code, cod);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
        WebElement panNo = driver.findElement(By.xpath("//android.widget.FrameLayout[@resource-id=\"android:id/content\"]/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.EditText[5]"));
        Swrite(panNo, pan);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));

        WebElement creditLimit = driver.findElement(By.xpath("(//android.widget.EditText[@text=\"0\"])[1]"));
        Swrite(creditLimit,creL);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
        WebElement creditAmo = driver.findElement(By.xpath("//android.widget.EditText[@text=\"0\"]"));
        Swrite(creditAmo, creA);
        driver.pressKey(new KeyEvent(AndroidKey.ENTER));
        
        Aclick(category);
        Aclick(categorySelect);
        
        Aclick(save);
        
        System.out.println();
        System.out.println("*** Successfully created customer ***");
        System.out.println();
        
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
    }
    
}
