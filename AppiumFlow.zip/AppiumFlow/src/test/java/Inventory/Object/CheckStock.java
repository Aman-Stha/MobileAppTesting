/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inventory.Object;

import Inventory.Base.BasePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author aman
 */
public class CheckStock extends BasePage {
    
    public CheckStock(AndroidDriver driver) {
        
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }
    
    By search = By.xpath("//android.widget.EditText");    
    By productBtn = By.xpath("//android.view.View[@content-desc=\"PRODUCT\"]");
//    By back = By.xpath("//android.widget.Button[@content-desc=\"Back\"]");
    
    public String StockCheck(String prod) throws InterruptedException {
        
        Aclick(search);
        
        driver.findElement(search).sendKeys(prod);
        Thread.sleep(1000);

        // Try to locate "No items found!" message (result1)
        try {
            WebElement result1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.view.View[@content-desc='No items found!']")));
            if (result1.isDisplayed()) {
                System.out.println();
                System.out.println("*** Total Stock of Product " + prod + " is: 0 ***");
                System.out.println();
                driver.pressKey(new KeyEvent(AndroidKey.BACK));
                driver.pressKey(new KeyEvent(AndroidKey.BACK));
                Aclick(productBtn);
                return "0";
            }
            
        } catch (TimeoutException e) {
            // If "No items found!" is not visible, proceed to check for the product itself
        }

        // Locate the product element (result2) only if "No items found!" was not found
        try {
            List<WebElement> proList = driver.findElements(By.xpath("//android.view.View"));
            WebElement proOpt = proList.get(9);
            proOpt.click();
            
            List<WebElement> stockList = driver.findElements(By.xpath("//android.view.View"));
            WebElement SelectS = stockList.get(8);
            String stockText = SelectS.getAttribute("content-desc");
            
            String[] values = stockText.split("-"); // Split by "-"
            String finalStock = values[1].trim();  // Get the second part and trim spaces
            
            System.out.println();
            System.out.println("*** Total Stock of Product " + prod + " is: "+ finalStock +" ***");
            System.out.println();
            
            driver.pressKey(new KeyEvent(AndroidKey.BACK));
            driver.pressKey(new KeyEvent(AndroidKey.BACK));
            Aclick(productBtn);
            return finalStock;
        } catch (TimeoutException e) {
        }
        return null;
    }
    
    
}
